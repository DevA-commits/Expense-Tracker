<div class="modal fade create_edit_modal" id="edit_modal">
    <div class="modal-dialog modal-sm">
        <div class="modal-content create_edit_modal_content">

        </div>
    </div>
</div>
