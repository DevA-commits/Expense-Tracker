<!-- right offcanvas -->
<div class="offcanvas offcanvas-end right_canvas" tabindex="-1" id="offcanvasRight" aria-labelledby="offcanvasRightLabel">

</div>
