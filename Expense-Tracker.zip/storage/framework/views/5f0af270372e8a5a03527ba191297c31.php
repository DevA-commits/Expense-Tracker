<!DOCTYPE html>
<html>

<head>
    <title>Expense Report</title>
    <style>
        /* Add your custom styles here */
        body {
            font-family: monospace;
            font-size: 14px;
        }

        .header {
            text-align: center;
            margin-bottom: 20px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        table,
        th,
        td {
            border: 1px solid black;
        }

        th,
        td {
            padding: 10px;
            text-align: left;
        }
    </style>
</head>

<body>
    <div class="header">
        <h2>Expense Report</h2>
        <p>From: <?php echo e($fromDate->format('d-m-Y')); ?> To: <?php echo e($toDate->format('d-m-Y')); ?></p>
    </div>
    <table>
        <thead>
            <tr>
                <th>Merchant Name</th>
                <th>Date Of Spend</th>
                <th>Payment Method</th>
                <th>Currency</th>
                <th>Expense Category</th>
                <th>Amount</th>
            </tr>
        </thead>
        <tbody>
            <?php
                $totalAmount = 0;
            ?>
            <?php $__currentLoopData = $expenses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expense): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($expense->merchant_name); ?></td>
                            <td><?php echo e($expense->date_of_spend); ?></td>
                            <td><?php echo e($expense->paymentMethod->title); ?></td>
                            <td>
                                <?php if($expense->currency->title === 'Indian Rupee (INR)'): ?>
                                    INR
                                <?php else: ?>
                                    <?php echo e($expense->currency->title); ?>

                                <?php endif; ?>
                            </td>
                            <td><?php echo e($expense->expenseCategory->title); ?></td>
                            <td><?php echo e($expense->amount_spent); ?></td>
                        </tr>
                        <?php
                            $totalAmount += $expense->amount_spent;
                        ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        <tfoot>
            <tr class="total-row">
                <td colspan="5" class="total-label">Total Amount:</td>
                <td><?php echo e($totalAmount); ?></td>
            </tr>
        </tfoot>
    </table>
</body>

</html><?php /**PATH D:\FreeLance\Expense-Tracker\resources\views/Admin/pages/report/download_report/pdf.blade.php ENDPATH**/ ?>