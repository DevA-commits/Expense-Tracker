<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm-6">
                <script>
                    document.write(new Date().getFullYear())
                </script> © LARAVEL.
            </div>
            <div class="col-sm-6">
                <div class="text-sm-end d-none d-sm-block">
                    Design & Develop 
                </div>
            </div>
        </div>
    </div>
</footer><?php /**PATH D:\FreeLance\app\resources\views/Admin/layouts/partials/_footer.blade.php ENDPATH**/ ?>