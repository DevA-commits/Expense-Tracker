
<?php $__env->startSection('title', 'EXPENSE | CREATE'); ?>
<?php $__env->startSection('content'); ?>
<div class="page-content">
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box d-sm-flex align-items-center justify-content-between">
                    <h4 class="mb-sm-0">Manage Expense</h4>

                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">

                            <li class="breadcrumb-item"><a href="javascript: void(0);">Expense</a>
                            </li>
                            <li class="breadcrumb-item active">Manage Expense</li>
                        </ol>
                    </div>

                </div>
            </div>
        </div>
        <!-- end page title -->
        <div class="row">
            <div class="col-xl-12">
                <div class="card">
                    <div class="card-header bg-success">
                        <h4 class="card-title">Create Expense</h4>
                    </div>
                    <div class="card-body">
                        <form id="save" autocomplete="off">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="payment_method" class="required">Payment Method</label>
                                        <select name="payment_method" id="payment_method" class="form-control">
                                            <option value="">--Select Option--</option>
                                            <?php $__currentLoopData = $paymentMethods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentMethod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($paymentMethod->id); ?>"><?php echo e($paymentMethod->title); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="invalid-feedback" id="payment_method_error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="merchant_name" class="required">Merchant Name</label>
                                        <input type="text" name="merchant_name" id="merchant_name" class="form-control"
                                            placeholder="Enter merchant name">
                                        <span class="invalid-feedback" id="merchant_name_error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="date_of_spend" class="required">Date of Spend</label>
                                        <input type="date" name="date_of_spend" id="date_of_spend" class="form-control"
                                            value="<?php echo e(date('Y-m-d')); ?>">
                                        <span class="invalid-feedback" id="date_of_spend_error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="currency" class="required">Currency</label>
                                        <select name="currency" id="currency" class="form-control">
                                            <?php $__currentLoopData = $currencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($currency->id); ?>"><?php echo e($currency->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="invalid-feedback" id="currency_error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="amount_spent" class="required">Amount Spent</label>
                                        <input type="number" name="amount_spent" id="amount_spent" class="form-control"
                                            placeholder="Enter amount spent">
                                        <span class="invalid-feedback" id="amount_spent_error"></span>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group mb-3">
                                        <label for="expense_category" class="required">Category</label>
                                        <select name="expense_category" id="expense_category" class="form-control">
                                            <option value="">--Select Option--</option>
                                            <?php $__currentLoopData = $expensecategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $expensecategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($expensecategory->id); ?>"><?php echo e($expensecategory->title); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <span class="invalid-feedback" id="expense_category_error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group mb-3">
                                        <label for="description" class="required">Description</label>
                                        <textarea name="description" id="description" class="form-control"
                                            placeholder="Enter description"></textarea>
                                        <span class="invalid-feedback" id="description_error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group mb-3">
                                        <label for="attendees" class="required">Attendees (comma-separated)</label>
                                        <input type="text" name="attendees" id="attendees" class="form-control"
                                            placeholder="Enter attendees (comma-separated)" value="Myself, ">
                                        <span class="invalid-feedback" id="attendees_error"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="text-end">
                                        <button id="save_btn" class="btn btn-success" type="submit">Create</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('modal'); ?>
<?php echo $__env->make('Admin._includes.offcanvas.right', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('Admin._includes.modals.delete_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script src="<?php echo e(url('assets/js/main/canvas.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/main/delete.js')); ?>"></script>

    <script>
        $('#save').submit(function (event) {
            event.preventDefault();

            var formData = new FormData(this);
            $.ajax({
                url: "<?php echo e(route('admin.store')); ?>",
                method: "POST",
                data: formData,
                dataType: "json",
                contentType: false,
                processData: false,
                cache: false,
                beforeSend: function () {
                    $('#save_btn').attr('disabled', true);
                    $('#save_btn').html(window.spinner);
                },
            }).done((response, statusText, xhr) => {
                $(".error-text").text("");
                $(".form-control").removeClass("is-invalid");
                $('#save_btn').removeAttr('disabled');
                $('#save_btn').html('Create');

                if (xhr.status == 201) {
                    $("#save")[0].reset();
                    toastr(response.message, "bg-success");
                }
                if (xhr.status == 200) {
                    toastr(response.message, "bg-success");
                }
            }).fail((error) => {
                $(".error-text").text("");
                $(".form-control").removeClass("is-invalid");
                $('#save_btn').removeAttr('disabled');
                $('#save_btn').html('Create');

                if (error.status == 422) {
                    $.each(error.responseJSON, function (key, val) {
                        $("#" + key).addClass("is-invalid");
                        $("#" + key + "_error").text(val[0]);
                    });
                } else {
                    toastr(error.responseJSON.message, "bg-danger");
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('Admin.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\FreeLance\app\resources\views/Admin/pages/expanse/index.blade.php ENDPATH**/ ?>