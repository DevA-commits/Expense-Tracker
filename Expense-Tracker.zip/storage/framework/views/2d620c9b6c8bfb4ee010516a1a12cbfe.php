<div class="offcanvas-header bg-danger">
    <h5 id="offcanvasRightLabel" class="text-light">Edit Payment Method</h5>
    <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
</div>
<div class="offcanvas-body">
    <form id="update" autocomplete="off">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <input type="hidden" name="payment_id" id="edit_payment_id" value="<?php echo e(encrypt($paymentMethods->id)); ?>">

        <div class="form-group mb-3">
            <label for="title" class="required">Payment Method Type</label>
            <select name="title" id="title" class="form-control">
                <?php $__currentLoopData = $payments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($payment->id); ?>" selected>
                        <?php echo e(ucwords(str_replace('_', ' ', $payment->title))); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <span class="invalid-feedback" id="edit_title_error"></span>
        </div>

        <div class="form-group mb-3">
            <label for="payment_name" class="required">User payment_name</label>
            <input type="payment_name" name="payment_name" required maxlength="50" id="edit_payment_name"
                value="<?php echo e($paymentMethods->payment_name); ?>" class="form-control" placeholder="Enter Payment Name">
            <span class="invalid-feedback" id="edit_payment_name_error"></span>
        </div>

        <center>
            <button type="submit" id="update_btn" class="btn btn-block btn-primary">Update</button>
        </center>
    </form>


</div>
<script>
    $('#update').submit(function (event) {
        event.preventDefault();
        var formData = new FormData(this);

        $.ajax({
            url: "<?php echo e(route('user.payment.update')); ?>",
            method: "POST",
            data: formData,
            dataType: "json",
            contentType: false,
            processData: false,
            cache: false,
            beforeSend: function () {
                $('#update_btn').attr('disabled', true);
                $('#update_btn').html(window.spinner);
            },
        }).done((response, statusText, xhr) => {
            $(".error-text").text("");
            $(".form-control").removeClass("is-invalid");
            $('#update_btn').removeAttr('disabled');
            $('#update_btn').html('update');


            if (xhr.status == 200) {

                $("#datatable").DataTable().ajax.reload();

                let myOffCanvas = document.getElementById('offcanvasRight');
                let openedCanvas = bootstrap.Offcanvas.getInstance(myOffCanvas);
                openedCanvas.hide();
                toastr(response.message, "bg-success");
            }

        }).fail((error) => {
            $(".error-text").text("");
            $(".form-control").removeClass("is-invalid");
            $('#update_btn').removeAttr('disabled');
            $('#update_btn').html('update');

            if (error.status == 422) {

                $.each(error.responseJSON, function (key, val) {
                    $("#edit_" + key).addClass("is-invalid");
                    $("#edit_" + key + "_error").text(val[0]);
                });
            } else {
                toastr(error.responseJSON.message, "bg-danger");
            }
        });
    });
</script><?php /**PATH D:\FreeLance\Expense-Tracker\resources\views/Admin/pages/payment_method/edit.blade.php ENDPATH**/ ?>